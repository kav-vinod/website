import logo from './logo.svg';
import './App.css';
import NameTag from './components/NameTag';
import Home from './components/Home';
import HomeStart from './components/HomeStart';
import Navbar from './components/Navbar';
import { Route, BrowserRouter as Router, Routes } from 'react-router-dom'; 
//import MainPage from './components/MainPage';

function App() {
  return (
    <div className="App">
      <Router>
        <Navbar/>
        <Routes>
          <Route path="/" element={<Home/>} />
        </Routes>
        <Routes>
          <Route path="/start" element={<HomeStart/>} />
        </Routes>
      </Router>
    </div>
    //<MainPage/>
  );
}

export default App;
