import { NavLink, useNavigate } from 'react-router-dom'
import HomeStart from './HomeStart.js'
const Navbar = () => {
    const navigate = useNavigate();

    const handleNavLinkClick = (route, stateProps) => {
        // Reload the page
        //window.location.reload();
        navigate(route, {state: stateProps});
    };
    return(
        <header className="header">
            <NavLink to="/" className="w-20 h-10 rounded-lg bg-white items-center justify-center flex font-bold shadow-md">
                <p className="blue-gradient_text">Home</p>
            </NavLink>
            <nav className="flex text-lg gap-5 font-bold">
                <NavLink to="/start" 
                    onClick={() => handleNavLinkClick("/start", {camPosX : 0, camPosY : 0, camPosZ : 180 })} 
                     state = {{camPosX : 0, camPosY : 0, camPosZ : 180 }}
                     className="text-black hover:text-blue-500">
                    <p>Start</p>
                </NavLink>
                <NavLink to="/start" 
                    onClick={() => handleNavLinkClick} 
                    state = {{camPosX : 75, camPosY : 0, camPosZ : -129.904 }}
                    className="text-black hover:text-blue-500">
                    <p > Experience</p>
                </NavLink>
                <NavLink to="/start" 
                    onClick={() => handleNavLinkClick} 
                     state = {{camPosX : -150, camPosY : 0, camPosZ : 0 }}
                    className="text-black hover:text-blue-500">
                    <p >Projects</p>
                </NavLink>
                <NavLink to="/start" 
                    onClick={handleNavLinkClick } 
                    state = {{camPosX : 75, camPosY : 0, camPosZ : 129.904 }}
                    className="text-black hover:text-blue-500">
                     <p >About Me!</p>
                </NavLink>
            </nav>  
            
        </header>
    )
}

export default Navbar