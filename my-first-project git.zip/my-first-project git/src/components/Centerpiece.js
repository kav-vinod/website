import { useEffect } from 'react';
import * as THREE from 'three';

function Centerpiece({ scene, texturefp }) {

    useEffect(() => {
        //obtain texture
        const texture =  new THREE.TextureLoader().load(texturefp);
        const geometry = new THREE.DodecahedronGeometry(40, 0);
        const material = new THREE.MeshStandardMaterial({ map:texture });
        const centerpiece  = new THREE.Mesh(geometry, material);

        const animate = () => {
            // Update rotation
            centerpiece.rotation.x += 0.01; 
            centerpiece.rotation.y += 0.01; 

            requestAnimationFrame(animate); 
        };

        animate(); 
        
        centerpiece.position.set(0, 0, 0);
        scene.add(centerpiece); 
        console.log("Sphere Added")
        // Cleanup function to remove the mesh when component unmounts
        return () => {
            scene.remove(centerpiece); 
        };
    //[scene] b/c when scene changes, this component will be rerendered
    }, [scene]);

    // Since this is a Three.js component, it doesn't need to return anything
    return null;
} 

export default Centerpiece;